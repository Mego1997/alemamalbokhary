<!-- scrollToTop start here -->
<a href="#" class="scrollToTop"><i class="icofont-bubble-up"></i><span class="pluse_1"></span><span
        class="pluse_2"></span></a>
<!-- scrollToTop ending here -->


<script src="{{ url('public/frontend/assets/js/jquery.js') }}"></script>
<script src="{{ url('public/frontend/assets/js/fontawesome.min.js') }}"></script>
<script src="{{ url('public/frontend/assets/js/waypoints.min.js') }}"></script>
<script src="{{ url('public/frontend/assets/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ url('public/frontend/assets/js/swiper.min.js') }}"></script>
<script src="{{ url('public/frontend/assets/js/circularProgressBar.min.js') }}"></script>
<script src="{{ url('public/frontend/assets/js/isotope.pkgd.min.js') }}"></script>
<script src="{{ url('public/frontend/assets/js/lightcase.js') }}"></script>
<script src="{{ url('public/frontend/assets/js/functions.js') }}"></script>
